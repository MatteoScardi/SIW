package it.uniroma3.siw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiwBooks1Application {

	public static void main(String[] args) {
		SpringApplication.run(SiwBooks1Application.class, args);
	}

}
