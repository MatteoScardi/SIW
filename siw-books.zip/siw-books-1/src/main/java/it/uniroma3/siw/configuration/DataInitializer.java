package it.uniroma3.siw.configuration; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import it.uniroma3.siw.model.Credentials; 
import it.uniroma3.siw.model.User;         
import it.uniroma3.siw.repository.CredentialsRepository; 

@Component
public class DataInitializer implements CommandLineRunner {


    @Autowired
    private CredentialsRepository credentialsRepository; 

    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * Controlla se esistono già utenti "admin" e "user" nel database e, in caso contrario,
     * li crea con credenziali e ruoli predefiniti.
     */
    @Override
    public void run(String... args) throws Exception {
        // --- Inizializzazione utente Amministratore ---
        // Controlla se un utente con username "admin" esiste già nel database.
        // credentialsRepository.findByUsername("admin") restituisce un Optional,
        // .isEmpty() è vero se l'Optional è vuoto (cioè l'utente non esiste).
    	
        if (credentialsRepository.findByUsername("admin").isEmpty()) {
            // Se l'admin non esiste, crea un nuovo oggetto User per i dettagli personali dell'admin.
            User adminUser = new User();
            adminUser.setName("Admin");
            adminUser.setSurname("User");


            Credentials adminCredentials = new Credentials();
            adminCredentials.setUsername("admin");
            // Cripta la password "adminpassword" usando l'encoder prima di salvarla.
            adminCredentials.setPassword(passwordEncoder.encode("adminpassword")); 
            // Assegna il ruolo di amministratore (definito in Credentials.ADMIN_ROLE).
            adminCredentials.setRole(Credentials.ADMIN_ROLE);
            adminCredentials.setUser(adminUser); 

            // Salva le credenziali dell'amministratore (che a cascata salverà anche l'User associato)
            credentialsRepository.save(adminCredentials);
        }
         
        // --- Inizializzazione utente di Default ---
        // Fa lo stesso controllo per l'utente "user".
        if (credentialsRepository.findByUsername("user").isEmpty()) {
            User defaultUser = new User();
            defaultUser.setName("Mario");
            defaultUser.setSurname("Rossi");

            Credentials defaultCredentials = new Credentials();
            defaultCredentials.setUsername("user");
            // Cripta la password "userpassword".
            defaultCredentials.setPassword(passwordEncoder.encode("userpassword")); 
            // Assegna il ruolo di utente standard (definito in Credentials.DEFAULT_ROLE).
            defaultCredentials.setRole(Credentials.DEFAULT_ROLE);
            defaultCredentials.setUser(defaultUser);

            // Salva le credenziali dell'utente di default nel database.
            credentialsRepository.save(defaultCredentials);
        }
    }
}