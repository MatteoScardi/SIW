package it.uniroma3.siw.configuration; 


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.io.File; 


@Configuration
public class MvcConfig implements WebMvcConfigurer {

    // Inietta il valore della proprietà 'app.upload.book-images.path' dal file application.properties.
    // Se la proprietà non è definita, usa un valore di fallback: la directory corrente dell'utente
    // più "/uploads/book-images".
    @Value("${app.upload.book-images.path:${user.dir}/uploads/book-images}")
    private String uploadPathBookImages;

    // Inietta il valore della proprietà 'app.upload.author-photos.path' dal file application.properties.
    // Se la proprietà non è definita, usa un valore di fallback: la directory corrente dell'utente
    // più "/uploads/author-photos".
    @Value("${app.upload.author-photos.path:${user.dir}/uploads/author-photos}")
    private String uploadPathAuthorPhotos;

    /**
     * Questo metodo viene sovrascritto per configurare come l'applicazione
     * deve servire le risorse statiche (in questo caso, le immagini dei libri e degli autori).
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // --- Handler per le immagini dei libri ---
        // Questa parte assicura che il percorso di upload termini con un separatore di file
        String effectiveUploadPathBooks = uploadPathBookImages.endsWith(File.separator) 
                                         ? uploadPathBookImages 
                                         : uploadPathBookImages + File.separator;
        
        // Aggiunge un "resource handler": ogni richiesta che inizia con "/uploads/book-images/**"
        // verrà mappata alla directory fisica specificata da effectiveUploadPathBooks.
        // Questo permette al browser di accedere alle immagini caricate come se fossero parte
        // della struttura del sito web.
        registry.addResourceHandler("/uploads/book-images/**")
                .addResourceLocations("file:" + effectiveUploadPathBooks);

        // --- Handler per le foto degli autori ---
        // Stesso meccanismo per le foto degli autori.
        String effectiveUploadPathAuthors = uploadPathAuthorPhotos.endsWith(File.separator) 
                                            ? uploadPathAuthorPhotos 
                                            : uploadPathAuthorPhotos + File.separator;
        
        // Mappa le richieste "/uploads/author-photos/**" alla directory fisica delle foto degli autori.
        registry.addResourceHandler("/uploads/author-photos/**")
                .addResourceLocations("file:" + effectiveUploadPathAuthors);
    }
}