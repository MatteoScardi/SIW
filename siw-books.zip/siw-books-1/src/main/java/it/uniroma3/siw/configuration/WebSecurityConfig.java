package it.uniroma3.siw.configuration;

import static it.uniroma3.siw.model.Credentials.ADMIN_ROLE;
import static it.uniroma3.siw.model.Credentials.DEFAULT_ROLE;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;


@Configuration
@EnableWebSecurity
public class WebSecurityConfig {
	
	
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
    
    /**
     * Configura la catena di filtri di sicurezza HTTP.
     * Questo è il metodo principale dove si definiscono le regole di autorizzazione
     * per le diverse URL dell'applicazione, oltre alla configurazione del login e logout.
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            //.csrf(csrf -> csrf.disable()) 
            .authorizeHttpRequests(authorize -> authorize	// Inizia la configurazione delle regole di autorizzazione.
                    
                // Pagine accessibili a tutti (utenti occasionali)
            	.requestMatchers("/logo.png").permitAll()
                .requestMatchers(("/")).permitAll()
                .requestMatchers(("/index")).permitAll()
                .requestMatchers(("/css/**")).permitAll()
                .requestMatchers(("/images/**")).permitAll() // Anche per placeholder e icone
                .requestMatchers(("/uploads/book-images/**")).permitAll() // Se usi upload esterni
                .requestMatchers(("/uploads/author-photos/**")).permitAll() // Se usi upload esterni per foto autori
                .requestMatchers(("/autori")).permitAll()
                .requestMatchers(("/autore/**")).permitAll() // Dettaglio autore
                .requestMatchers(("/libri")).permitAll()
                .requestMatchers(("/libro/**")).permitAll() // Dettaglio libro
                .requestMatchers(("/login")).permitAll()
                .requestMatchers(("/register")).permitAll()
                .requestMatchers(("/recensioni")).permitAll() 
                .requestMatchers(("/recensione/**")).permitAll() 


                // Pagine accessibili solo agli utenti registrati (DEFAULT e ADMIN)
                .requestMatchers(("/user/**")).hasAnyRole(DEFAULT_ROLE, ADMIN_ROLE) 
                .requestMatchers(("/recensioneForm/**")).hasAnyRole(DEFAULT_ROLE, ADMIN_ROLE) // Form per nuova recensione


                // Pagine accessibili solo agli amministratori
                .requestMatchers(("/admin/**")).hasRole(ADMIN_ROLE)
                // Se i tuoi percorsi di eliminazione recensioni sono questi, assicurati siano corretti:
                .requestMatchers(("/recensione/elimina/**")).hasRole(ADMIN_ROLE) 

                // Tutte le altre richieste richiedono autenticazione
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .defaultSuccessUrl("/success", true) // 'true' per forzare sempre questo URL
                .failureUrl("/login?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
            );
        return http.build();
    }
}