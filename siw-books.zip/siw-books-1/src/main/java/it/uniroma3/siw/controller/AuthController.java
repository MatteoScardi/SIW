package it.uniroma3.siw.controller;

import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.service.CredentialsService;
import jakarta.validation.Valid; // Aggiunto per la validazione
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult; // Aggiunto per la gestione degli errori di validazione
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {

    @Autowired
    private CredentialsService credentialsService;

    @GetMapping("/login")
    public String showLoginForm() {
        return "login.html";
    }

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new User());
        model.addAttribute("credentials", new Credentials());
        return "register.html";
    }

    @PostMapping("/register")
    public String registerUser(@Valid @ModelAttribute("user") User user,
                               @Valid @ModelAttribute("credentials") Credentials credentials,
                               BindingResult userBindingResult, 		// Risultati della validazione per User
                               BindingResult credentialsBindingResult,  // Risultati della validazione per Credentials
                               Model model) {

        // Se ci sono errori di validazione per le credenziali o per l'utente
        if (userBindingResult.hasErrors() || credentialsBindingResult.hasErrors()) {
            return "register.html"; // Torna alla pagina di registrazione mostrando gli errori
        }

        // Verifica se l'username esiste già
        if (credentialsService.getCredentialsByUsername(credentials.getUsername()) != null) {
            model.addAttribute("duplicateUsername", "L'username " + credentials.getUsername() + " è già in uso.");
            return "register.html";
        }

        credentials.setUser(user);
        credentials.setRole(Credentials.DEFAULT_ROLE); // Assegna il ruolo di default
        credentialsService.saveCredentials(credentials);
        return "redirect:/login?registered=true"; // Reindirizza al login con un parametro per il successo
    }

    @GetMapping("/success")
    public String loginSuccess() {
        return "home.html"; 
    }
}