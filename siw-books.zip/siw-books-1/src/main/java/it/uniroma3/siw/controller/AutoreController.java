package it.uniroma3.siw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value; // Per il percorso di upload
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils; // Per pulire il nome del file
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import it.uniroma3.siw.model.Autore;
import it.uniroma3.siw.service.AutoreService;
import jakarta.validation.Valid;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Controller
public class AutoreController {

    @Autowired
    private AutoreService autoreService;

    @Value("${app.upload.author-photos.path:${user.dir}/uploads/author-photos}")
    private String uploadPathAuthorPhotos;

    
    @GetMapping("/autori")
    public String getAutori(Model model) {
        model.addAttribute("autori", autoreService.findAll());
        return "autori.html";
    }

    @GetMapping("/autore/{id}")
    public String getAutore(@PathVariable("id") Long id, Model model) {
        Autore autore = autoreService.findById(id);
         if (autore == null) {
            return "redirect:/autori?error=Autore non trovato";
        }
        model.addAttribute("autore", autore);
        return "autore.html"; 
    }

    @GetMapping("/admin/autoreForm")
    public String showNewAutoreForm(Model model) {
        model.addAttribute("autore", new Autore());
        return "admin/autoreForm.html";
    }

    @GetMapping("/admin/autoreForm/{id}")
    public String showEditAutoreForm(@PathVariable("id") Long id, Model model) {
        Autore autore = autoreService.findById(id);
        if (autore == null) {
            return "redirect:/autori?error=Autore non trovato";
        }
        model.addAttribute("autore", autore);
        return "admin/autoreForm.html";
    }

    @PostMapping("/admin/autore")
    public String saveAutore(@Valid @ModelAttribute("autore") Autore autore,
                             BindingResult bindingResult,
                             @RequestParam("fileFotografia") MultipartFile fileFotografia, // Aggiunto parametro
                             Model model) {

        // Gestione Upload Fotografia
        if (fileFotografia != null && !fileFotografia.isEmpty()) {
            try {
                String originalFileName = StringUtils.cleanPath(fileFotografia.getOriginalFilename());
                String fileExtension = "";
                int dotIndex = originalFileName.lastIndexOf('.');
                if (dotIndex > 0) {
                    fileExtension = originalFileName.substring(dotIndex);
                }
                String uniqueFileName = UUID.randomUUID().toString() + fileExtension;

                Path uploadDir = Paths.get(uploadPathAuthorPhotos);
                if (!Files.exists(uploadDir)) {
                    Files.createDirectories(uploadDir);
                }
                Path filePath = uploadDir.resolve(uniqueFileName);
                Files.copy(fileFotografia.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

                // Salva il percorso relativo che sarà usato nel tag <img>
                autore.setFotografia("/uploads/author-photos/" + uniqueFileName);

            } catch (IOException e) {
                // Gestisci l'errore di caricamento
                bindingResult.rejectValue("fotografia", "upload.error", "Errore durante il caricamento della fotografia: " + e.getMessage());
            }
        } else if (autore.getId() != null) { // Se è una modifica e non è stato caricato un nuovo file
            // Mantieni la foto esistente (non sovrascrivere con null o stringa vuota)
            Autore existingAutore = autoreService.findById(autore.getId());
            if (existingAutore != null) {
                autore.setFotografia(existingAutore.getFotografia());
            }
        }


        if (bindingResult.hasErrors()) {
            return "admin/autoreForm.html";
        }

        System.out.println("Salvando Autore: " + autore.getNome() + ", DataNascita: " + autore.getDataNascita() + ", Foto: " + autore.getFotografia());
        autoreService.save(autore);
        return "redirect:/autori";
    }

    @GetMapping("/admin/deleteAutore/{id}")
    public String deleteAutore(@PathVariable("id") Long id) {
    	
        Autore autore = autoreService.findById(id);
        if (autore != null && autore.getFotografia() != null && !autore.getFotografia().isEmpty()) {
            try {
                String fileName = autore.getFotografia().substring(autore.getFotografia().lastIndexOf("/") + 1);
                Path filePath = Paths.get(uploadPathAuthorPhotos, fileName);
                Files.deleteIfExists(filePath);
            } catch (IOException e) {
                System.err.println("Errore eliminazione foto per autore " + id + ": " + e.getMessage());
            }
        }
        autoreService.deleteById(id);
        return "redirect:/autori";
    }
}