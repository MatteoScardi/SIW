package it.uniroma3.siw.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption; // Importa per REPLACE_EXISTING (opzionale ma buono)
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value; // Per un approccio migliore alla directory di upload
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils; // Per pulire nomi file
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import it.uniroma3.siw.model.Autore;
import it.uniroma3.siw.model.Libro;
import it.uniroma3.siw.service.AutoreService;
import it.uniroma3.siw.service.LibroService;
import jakarta.validation.Valid;

@Controller
public class LibroController {

    @Autowired
    private LibroService libroService;

    @Autowired
    private AutoreService autoreService;

    @Value("${app.upload.book-images.path:${user.dir}/uploads/book-images}") // Default se non specificato
    private String uploadPathBookImages;


    @GetMapping("/")
    public String showHome() {
		return "home.html"; 
	}
    
    @GetMapping("/libri")
    public String getLibri(Model model) {
        model.addAttribute("libri", libroService.findAll());
        return "libri.html";
    }

    @GetMapping("/libro/{id}")
    public String getLibro(@PathVariable("id") Long id, Model model) {
        Libro libro = libroService.findById(id);
        if (libro == null) {
            return "redirect:/libri?error=notfound";
        }
        model.addAttribute("libro", libro);
        return "libro.html";
    }

    @GetMapping("/admin/libroForm")
    public String addLibroForm(Model model) {
        model.addAttribute("libro", new Libro());
        model.addAttribute("autori", autoreService.findAll());
        return "admin/libroForm.html"; 
    }

    @PostMapping("/admin/libro")
    public String addLibro(@Valid @ModelAttribute("libro") Libro libro,
                           BindingResult bindingResult,
                           @RequestParam("images") List<MultipartFile> files, 
                           @RequestParam(value = "selectedAuthors", required = false) List<Long> selectedAuthorIds, 
                           Model model) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("autori", autoreService.findAll());
            return "admin/libroForm.html"; 
        }

        // Gestione upload immagini
        List<String> uploadedImagePaths = new ArrayList<>();
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                if (file != null && !file.isEmpty()) {
                    try {
                        String originalFileName = StringUtils.cleanPath(file.getOriginalFilename());
                        String fileExtension = "";
                        int dotIndex = originalFileName.lastIndexOf('.');
                        if (dotIndex > 0) {
                            fileExtension = originalFileName.substring(dotIndex);
                        }
                        String uniqueFileName = UUID.randomUUID().toString() + fileExtension;

                        // USA IL PERCORSO INSERITO IN APPLICATION.PROPERTIES (uploadPathBookImages)
                        Path uploadDir = Paths.get(uploadPathBookImages);

                        // CREA LA DIRECTORY SE NON ESISTE
                        if (!Files.exists(uploadDir)) {
                            Files.createDirectories(uploadDir); // Crea tutte le directory padre necessarie
                        }

                        Path filePath = uploadDir.resolve(uniqueFileName);
                        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
                        
                        // Salva il percorso relativo che sarà usato nel tag <img>
                        // Questo deve corrispondere a come lo servi tramite MvcConfig
                        uploadedImagePaths.add("/uploads/book-images/" + uniqueFileName); 

                    } catch (IOException e) {
                        model.addAttribute("autori", autoreService.findAll());
                        // Aggiungi un messaggio di errore più specifico per l'utente, se vuoi
                        bindingResult.reject("image.upload.error", "Errore durante il caricamento dell'immagine: " + e.getMessage());
                        System.err.println("Errore upload immagine: " + e.getMessage()); 
                        return "admin/libroForm.html";
                    }
                }
            }
        }

        // Sovrascrivi o imposta le immagini solo se ne sono state caricate di nuove
        if (!uploadedImagePaths.isEmpty()) {
            libro.setImmagini(uploadedImagePaths);
        } else if (libro.getId() != null) { // Se è una modifica e non sono state caricate nuove immagini
            // Mantieni le immagini esistenti
            Libro existingLibro = libroService.findById(libro.getId());
            if (existingLibro != null) {
                libro.setImmagini(existingLibro.getImmagini());
            }
        }


        // Associazione autori
        if (selectedAuthorIds != null && !selectedAuthorIds.isEmpty()) {
            List<Autore> autoriDaAssociare = autoreService.findAllById(selectedAuthorIds);
            libro.setAutori(autoriDaAssociare); // Assegna la lista di autori al libro
        } else 
            libro.setAutori(new ArrayList<>()); 
        

        
        libroService.save(libro);
        return "redirect:/libri";
    }

    
    @GetMapping("/admin/libroForm/{id}")
    public String editLibroForm(@PathVariable("id") Long id, Model model) {
        Libro libro = libroService.findById(id);
        if (libro == null) {
            return "redirect:/libri?error=notfound";
        }
        model.addAttribute("libro", libro);
        model.addAttribute("autori", autoreService.findAll());
        return "admin/libroForm.html"; 
    }

    @GetMapping("/admin/deleteLibro/{id}")
    public String deleteLibro(@PathVariable("id") Long id) {
        // Logica opzionale per eliminare i file immagine dal server
        Libro libro = libroService.findById(id);
        if (libro != null && libro.getImmagini() != null) {
            for (String imagePathUrl : libro.getImmagini()) {
                try {
                    String fileName = imagePathUrl.substring(imagePathUrl.lastIndexOf("/") + 1);
                    Path filePath = Paths.get(uploadPathBookImages, fileName);
                    Files.deleteIfExists(filePath);
                } catch (IOException e) {
                    System.err.println("Errore eliminazione immagine " + imagePathUrl + ": " + e.getMessage());
                }
            }
        }
        libroService.deleteById(id);
        return "redirect:/libri";
    }
}