package it.uniroma3.siw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Libro;
import it.uniroma3.siw.model.Recensione;
import it.uniroma3.siw.service.CredentialsService;
import it.uniroma3.siw.service.LibroService;
import it.uniroma3.siw.service.RecensioneService;
import jakarta.validation.Valid;

@Controller
public class RecensioneController {

    @Autowired
    private RecensioneService recensioneService;

    @Autowired
    private LibroService libroService;

    @Autowired
    private CredentialsService credentialsService; 

    // Metodo per mostrare il form di aggiunta di una recensione a un libro specifico
    @GetMapping("/user/recensioneForm/{libroId}")
    public String addRecensioneForm(@PathVariable("libroId") Long libroId, Model model) {
        Libro libro = libroService.findById(libroId);
        if (libro == null) {
            return "redirect:/libri"; 
        }

        // Controllo se l'utente ha già recensito questo libro
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Credentials credentials = credentialsService.getCredentialsByUsername(userDetails.getUsername());
        
        if (recensioneService.existsByLibroAndUser(libro, credentials.getUser())) {
            model.addAttribute("errorMessage", "Hai già lasciato una recensione per questo libro.");
            return "redirect:/libro/" + libroId; // Reindirizza alla pagina del libro con messaggio di errore
        }

        Recensione recensione = new Recensione();
        recensione.setLibro(libro);
        model.addAttribute("recensione", recensione);
        return "user/recensioneForm.html"; 
    }

    // Metodo per gestire la sottomissione del form di aggiunta recensione
    @PostMapping("/user/recensione/{libroId}")
    public String addRecensione(@PathVariable("libroId") Long libroId,
                                @Valid @ModelAttribute("recensione") Recensione recensione,
                                BindingResult bindingResult,
                                Model model) {
        Libro libro = libroService.findById(libroId);
        if (libro == null) {
            return "redirect:/libri";
        }
        
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Credentials credentials = credentialsService.getCredentialsByUsername(userDetails.getUsername());

        // Secondo controllo per evitare recensioni multiple
        if (recensioneService.existsByLibroAndUser(libro, credentials.getUser())) {
            model.addAttribute("errorMessage", "Hai già lasciato una recensione per questo libro.");
            return "redirect:/libro/" + libroId;
        }

        if (bindingResult.hasErrors()) {
            model.addAttribute("libro", libro);
            return "user/recensioneForm.html";
        }

        recensione.setLibro(libro);
        recensione.setAutore(credentials.getUser()); // L'autore della recensione è l'utente registrato
        recensioneService.save(recensione);
        return "redirect:/libro/" + libroId;
    }

    // Metodo per eliminare una recensione (solo per amministratori)
    @GetMapping("/admin/deleteRecensione/{id}")
    public String deleteRecensione(@PathVariable("id") Long id) {
        Recensione recensione = recensioneService.findById(id);
        if (recensione != null) {
            Long libroId = recensione.getLibro().getId();
            recensioneService.deleteById(id);
            return "redirect:/libro/" + libroId;
        }
        return "redirect:/"; 
    }
}