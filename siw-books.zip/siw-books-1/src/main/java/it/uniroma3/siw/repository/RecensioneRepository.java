package it.uniroma3.siw.repository;

import it.uniroma3.siw.model.Libro;
import it.uniroma3.siw.model.Recensione;
import it.uniroma3.siw.model.User; // Assumendo che esista una classe User
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecensioneRepository extends CrudRepository<Recensione, Long> {
    boolean existsByLibroAndAutore(Libro libro, User autore);
}