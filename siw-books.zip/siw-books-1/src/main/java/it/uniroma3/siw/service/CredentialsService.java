package it.uniroma3.siw.service;

import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.repository.CredentialsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder; // Assicurati di iniettare PasswordEncoder
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Importa @Transactional

@Service
public class CredentialsService {

    @Autowired
    private CredentialsRepository credentialsRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Transactional
    public Credentials saveCredentials(Credentials credentials) {
        // Codifica la password prima di salvarla (se non è già codificata)
        if (credentials.getPassword() != null && !credentials.getPassword().startsWith("$2a$")) { // Controlla se è già BCrypt
             credentials.setPassword(this.passwordEncoder.encode(credentials.getPassword()));
        }

        return credentialsRepository.save(credentials);
    }

    @Transactional
    public Credentials getCredentialsByUsername(String username) {
        return credentialsRepository.findByUsername(username).orElse(null);
    }

    public CredentialsRepository getCredentialsRepository() {
        return credentialsRepository;
    }
}