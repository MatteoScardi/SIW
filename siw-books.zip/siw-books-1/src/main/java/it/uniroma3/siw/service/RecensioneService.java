package it.uniroma3.siw.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Libro;
import it.uniroma3.siw.model.Recensione;
import it.uniroma3.siw.model.User; // Assumendo che esista una classe User legata a Credentials
import it.uniroma3.siw.repository.RecensioneRepository;

@Service
public class RecensioneService {

    @Autowired
    private RecensioneRepository recensioneRepository;

    public Recensione findById(Long id) {
        return recensioneRepository.findById(id).orElse(null);
    }

    public List<Recensione> findAll() {
        return (List<Recensione>) recensioneRepository.findAll();
    }

    public Recensione save(Recensione recensione) {
        return recensioneRepository.save(recensione);
    }

    public void deleteById(Long id) {
        recensioneRepository.deleteById(id);
    }

    public boolean existsByLibroAndUser(Libro libro, User user) {
        return recensioneRepository.existsByLibroAndAutore(libro, user);
    }
}